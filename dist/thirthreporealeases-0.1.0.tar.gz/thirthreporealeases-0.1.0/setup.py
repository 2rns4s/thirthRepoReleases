from setuptools import setup, find_packages

setup(
    name="ThirthRepoRealeases",                     # Nombre del paquete
    version="0.1.0",                                # Versión inicial
    packages=find_packages(),                       # Paquetes a incluir
    description="Un paquete pip simple de saludo",  # Breve descripción
    author="Daniel Osorio",                         # Tu nombre
    author_email="yonosoyosorio@gmail.com",         # Tu correo electrónico
    url="https://github.com/2rns4s/thirthRepoReleases",     # URL del proyecto
)